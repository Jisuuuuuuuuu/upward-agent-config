#!/usr/bin/env python3
"""Export a traceability ledger from the cleaned evidence workbook. Does not claim text is raw."""
import argparse, csv, json, sys
from openpyxl import load_workbook

SOURCE_MAP = {
    "b站评论(1).xlsx": "SRC_BILI",
    "小红书评论.csv": "SRC_XHS",
    "脊柱侧弯案例(1).docx": "SRC_YUMIN_CASE",
    "思思(1).docx": "SRC_SISI_CASE",
}
REQUIRED = ["编号", "来源文件", "原始条目编号", "清洗后的单条内容", "来源属性/备注"]
FIELDS = [
    "evidence_id", "source_id", "source_file", "original_item_id",
    "cleaned_text", "source_attribute", "text_layer", "verification_status"
]

def main():
    ap = argparse.ArgumentParser(description="从清洗证据索引生成证据溯源台账")
    ap.add_argument("--workbook", required=True, help="背背佳_访谈资料清洗整理.xlsx")
    ap.add_argument("--sheet", default="汇总总表")
    ap.add_argument("--csv", default="evidence_ledger.csv")
    ap.add_argument("--jsonl", default=None)
    args = ap.parse_args()

    wb = load_workbook(args.workbook, read_only=True, data_only=True)
    if args.sheet not in wb.sheetnames:
        raise SystemExit(f"找不到工作表：{args.sheet}")
    ws = wb[args.sheet]
    rows = ws.iter_rows(values_only=True)
    headers = [str(x).strip() if x is not None else "" for x in next(rows)]
    missing = [h for h in REQUIRED if h not in headers]
    if missing:
        raise SystemExit("缺少必要字段：" + ", ".join(missing))
    idx = {h: headers.index(h) for h in REQUIRED}

    records, seen = [], set()
    for row in rows:
        if not row or row[idx["编号"]] is None:
            continue
        evidence_id = str(row[idx["编号"]]).zfill(4)
        if evidence_id in seen:
            raise SystemExit(f"发现重复证据编号：{evidence_id}")
        seen.add(evidence_id)
        source_file = str(row[idx["来源文件"]] or "")
        source_id = SOURCE_MAP.get(source_file, "SRC_UNMAPPED")
        records.append({
            "evidence_id": evidence_id,
            "source_id": source_id,
            "source_file": source_file,
            "original_item_id": str(row[idx["原始条目编号"]] or ""),
            "cleaned_text": str(row[idx["清洗后的单条内容"]] or ""),
            "source_attribute": str(row[idx["来源属性/备注"]] or ""),
            "text_layer": "cleaned_excerpt",
            "verification_status": "indexed_not_independently_rechecked_against_original"
        })
    wb.close()

    if len(records) != 1391:
        print(f"警告：当前索引记录数为{len(records)}，项目当前manifest记录数为1391；请核对是否使用了其他版本。", file=sys.stderr)
    if any(r["source_id"] == "SRC_UNMAPPED" for r in records):
        raise SystemExit("存在无法映射的来源文件名，请更新SOURCE_MAP后再导出。")

    with open(args.csv, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(records)

    if args.jsonl:
        with open(args.jsonl, "w", encoding="utf-8") as f:
            for r in records:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")

    print(f"已导出{len(records)}条证据台账。")
    print("注意：cleaned_text是清洗后的证据文本，不等同于原始文件逐字全文；请使用source_file和original_item_id回查。")
    print(f"CSV：{args.csv}")
    if args.jsonl:
        print(f"JSONL：{args.jsonl}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
