#!/usr/bin/env python3
"""Validate session-log structure, source traceability, role voice, and workflow order."""
import argparse, json, re, sys

SIMULATION_EVENTS = [
    "identity_disclosed", "simulation_disclosed", "source_manifest_verified",
    "role_confirmed", "interview_started", "interview_ended", "debrief_completed"
]
HUMAN_EVENTS = [
    "identity_disclosed", "purpose_explained", "data_handling_explained",
    "voluntary_participation_explained", "right_to_skip_or_stop_explained",
    "consent_confirmed", "scope_confirmed", "interview_started",
    "interview_ended", "debrief_completed"
]
ALLOWED_RELATIONS = {"quote", "paraphrase", "summary", "researcher_interpretation"}
NO_SOURCE_PHRASES = ("原始资料未提及", "无法从当前来源确认", "现有材料无法确认", "当前证据不足")

def in_range(eid, start, end):
    try:
        n, a, b = int(str(eid)), int(start), int(end)
        return a <= n <= b
    except Exception:
        return False

def main():
    ap = argparse.ArgumentParser(description="验证访谈session log")
    ap.add_argument("--session", required=True)
    ap.add_argument("--manifest", default="assets/source_manifest.json")
    args = ap.parse_args()

    with open(args.session, "r", encoding="utf-8") as f:
        s = json.load(f)
    with open(args.manifest, "r", encoding="utf-8") as f:
        m = json.load(f)

    errors, warnings = [], []
    def require(condition, message):
        if not condition:
            errors.append(message)

    require(s.get("session_id"), "缺少session_id")
    require(s.get("mode") in {"simulation", "human_participant"}, "mode必须是simulation或human_participant")
    require(s.get("assistant_identity") == "AI研究访谈模拟助手", "assistant_identity必须保持AI研究访谈模拟助手")
    require(s.get("identity_disclosed") is True, "未记录身份披露")
    require(s.get("source_manifest", {}).get("verified") is True, "source_manifest未标记为已核验")
    require(s.get("session_ended") is True, "session_ended必须为true")
    require(s.get("debrief_completed") is True, "debrief_completed必须为true")

    mode = s.get("mode")
    consent = s.get("consent", {})
    if mode == "simulation":
        require(s.get("simulation_disclosed") is True, "模拟模式必须明确披露simulation")
        require(consent.get("status") == "not_applicable_simulation", "模拟模式consent.status必须为not_applicable_simulation")
    else:
        require(s.get("simulation_disclosed") is False, "真实受访者访谈不得标记为模拟")
        require(consent.get("status") == "obtained", "真实访谈必须记录明确同意")
        for field in ("purpose_disclosed", "voluntary_disclosed", "right_to_skip_or_stop_disclosed", "privacy_and_data_use_disclosed"):
            require(consent.get(field) is True, f"真实访谈缺少知情说明：{field}")

    events = [e.get("event") for e in s.get("workflow_events", [])]
    required_events = SIMULATION_EVENTS if mode == "simulation" else HUMAN_EVENTS
    positions = []
    for event in required_events:
        if event not in events:
            errors.append(f"流程缺少事件：{event}")
        else:
            positions.append(events.index(event))
    require(positions == sorted(positions), "访谈流程事件顺序不正确")
    if mode == "human_participant" and consent.get("status") != "obtained" and "interview_started" in events:
        errors.append("未取得同意却开始了真实访谈")

    source_by_id = {x["source_id"]: x for x in m.get("sources", [])}
    turns = s.get("turns", [])
    seen_turns = set()
    for turn in turns:
        tid = turn.get("turn_id")
        if not tid or tid in seen_turns:
            errors.append(f"turn_id缺失或重复：{tid}")
        seen_turns.add(tid)
        if turn.get("speaker") != "assistant" or turn.get("turn_type") not in {"answer", "response", "summary"}:
            continue

        refs = turn.get("source_refs", [])
        if not refs:
            no_source = turn.get("evidence_status") == "not_in_source" and any(p in turn.get("content", "") for p in NO_SOURCE_PHRASES)
            require(no_source, f"{tid}是实质性回答但没有证据引用；若资料未提及，须明确说明")
            continue

        for ref in refs:
            sid = ref.get("source_id")
            require(sid in source_by_id, f"{tid}引用了manifest中不存在的source_id：{sid}")
            require(bool(ref.get("evidence_ids")), f"{tid}的source_ref缺少evidence_ids")
            require(ref.get("relation") in ALLOWED_RELATIONS, f"{tid}的relation无效：{ref.get('relation')}")
            require(bool(ref.get("source_locator")), f"{tid}的source_ref缺少source_locator")
            require(bool(ref.get("supported_claim")), f"{tid}的source_ref缺少supported_claim")
            if sid in source_by_id:
                span = source_by_id[sid].get("evidence_ids", {})
                for eid in ref.get("evidence_ids", []):
                    require(in_range(eid, span.get("start"), span.get("end")), f"{tid}的证据编号{eid}不属于{sid}登记范围")

            voice = turn.get("role_voice", "")
            if sid == "SRC_SISI_CASE":
                require(voice == "third_person_case_narrative", f"{tid}引用思思案例时必须使用第三人称")
            if voice == "first_person_source_narrator":
                require(ref.get("self_report_confirmed") is True, f"{tid}使用第一人称但未确认原文为本人自述")
                require(sid != "SRC_SISI_CASE", f"{tid}不得以思思案例进行第一人称模拟")
            if voice == "verified_patient":
                errors.append(f"{tid}不得将网络来源自动标记为verified_patient")

    privacy = s.get("privacy", {})
    for field in ("real_names_removed", "usernames_not_reproduced", "unnecessary_identifiers_omitted"):
        if privacy.get(field) is not True:
            warnings.append(f"隐私字段未确认：{field}")

    safety = s.get("safety", {})
    if safety.get("medical_diagnosis_given") is True:
        errors.append("日志记录了模型给出诊断，违反医疗边界")
    if safety.get("individualized_treatment_advice_given") is True:
        errors.append("日志记录了个体化治疗建议，违反医疗边界")

    print("访谈日志核验")
    for w in warnings:
        print("[WARN]", w)
    for e in errors:
        print("[FAIL]", e)
    if errors:
        print(f"\n未通过：{len(errors)}项错误，{len(warnings)}项提醒")
        return 1
    print(f"\n通过：{len(turns)}轮记录，流程顺序与来源引用结构符合检查规则。")
    if warnings:
        print("仍有隐私记录提醒，请人工确认。")
    print("注意：结构验证不代表来源真实性或医学结论已得到证明。")
    return 0

if __name__ == "__main__":
    sys.exit(main())
