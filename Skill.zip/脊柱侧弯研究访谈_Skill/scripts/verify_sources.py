#!/usr/bin/env python3
"""Verify original files, source locators, and the cleaned evidence index."""
import argparse, csv, hashlib, json, os, re, sys, zipfile
import xml.etree.ElementTree as ET

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def count_csv_records(path):
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return max(0, sum(1 for _ in csv.reader(f)) - 1)

def docx_nonempty_paragraphs(path):
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml")
    root = ET.fromstring(xml)
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    result = []
    for para in root.findall(".//w:p", ns):
        text = "".join(t.text or "" for t in para.findall(".//w:t", ns))
        if text.strip():
            result.append(text)
    return result

def count_docx_paragraphs(path):
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml")
    root = ET.fromstring(xml)
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    return len(root.findall(".//w:p", ns))

def load_openpyxl():
    try:
        from openpyxl import load_workbook
        return load_workbook
    except ImportError:
        raise RuntimeError("缺少openpyxl，请先运行：python -m pip install openpyxl")

def check_source_structure(path, item, load_workbook):
    fmt = item["format"]
    expected = item.get("observed_record_count")
    if fmt == "csv":
        actual = count_csv_records(path)
    elif fmt == "docx":
        actual = count_docx_paragraphs(path)
        nonempty = len(docx_nonempty_paragraphs(path))
        expected_nonempty = item.get("observed_nonempty_record_count")
        if expected_nonempty is not None and nonempty != expected_nonempty:
            return actual, f"Word段落总数{actual}；非空段落数不匹配：期望{expected_nonempty}，实际{nonempty}"
    elif fmt == "xlsx":
        wb = load_workbook(path, read_only=True, data_only=True)
        sheet = item["locator"]["sheet"]
        if sheet not in wb.sheetnames:
            raise ValueError(f"缺少工作表：{sheet}")
        actual = max(0, wb[sheet].max_row - 1)
        wb.close()
    else:
        return None, "未配置该文件格式的结构计数"
    return actual, ("匹配" if expected is None or actual == expected else f"记录数不匹配：期望{expected}，实际{actual}")

def load_original_locator_maps(root, sources, load_workbook):
    maps = {}
    for item in sources:
        path = os.path.join(root, item["file_name"])
        if not os.path.isfile(path):
            continue
        sid = item["source_id"]
        if item["format"] == "xlsx":
            wb = load_workbook(path, read_only=True, data_only=True)
            ws = wb[item["locator"]["sheet"]]
            rows = ws.iter_rows(values_only=True)
            headers = [str(x).strip() if x is not None else "" for x in next(rows)]
            key_col = headers.index(item["locator"]["record_key"])
            text_col = headers.index(item["locator"]["text_column"])
            maps[sid] = {str(int(r[key_col])): str(r[text_col] or "") for r in rows if r and r[key_col] is not None}
            wb.close()
        elif item["format"] == "csv":
            with open(path, "r", encoding="utf-8-sig", newline="") as f:
                rows = list(csv.DictReader(f))
            text_col = item["locator"]["text_column"]
            maps[sid] = {str(i + 2): str(r.get(text_col, "") or "") for i, r in enumerate(rows)}
        elif item["format"] == "docx":
            paras = docx_nonempty_paragraphs(path)
            maps[sid] = {str(i + 1): text for i, text in enumerate(paras)}
    return maps

def check_index(path, index_item, manifest, root, load_workbook):
    wb = load_workbook(path, read_only=True, data_only=True)
    sheet_name = index_item["verification"]["sheet"]
    if sheet_name not in wb.sheetnames:
        raise ValueError(f"清洗索引缺少工作表：{sheet_name}")
    ws = wb[sheet_name]
    rows = list(ws.iter_rows(values_only=True))
    headers = [str(x).strip() if x is not None else "" for x in rows[0]]
    v = index_item["verification"]
    id_i = headers.index(v["id_column"])
    src_i = headers.index(v["source_column"])
    item_i = headers.index("原始条目编号")
    text_i = headers.index("清洗后的单条内容")
    data = [r for r in rows[1:] if r and r[id_i] is not None]
    ids = [str(r[id_i]).zfill(4) for r in data]
    duplicate_count = len(ids) - len(set(ids))
    contiguous = ids == [f"{i:04d}" for i in range(1, len(ids) + 1)]
    counts = {}
    for r in data:
        source_name = str(r[src_i])
        counts[source_name] = counts.get(source_name, 0) + 1
    expected_counts = v.get("expected_source_counts", {})
    mismatches = {k: (expected, counts.get(k, 0)) for k, expected in expected_counts.items() if counts.get(k, 0) != expected}
    wb.close()

    # Verify that every cleaned record's original locator exists in its original file.
    source_by_file = {x["file_name"]: x for x in manifest.get("sources", [])}
    locator_maps = load_original_locator_maps(root, manifest.get("sources", []), load_workbook)
    locator_missing, exact_matches, exact_checks = [], 0, 0
    for r in data:
        source_file = str(r[src_i])
        item = str(r[item_i] or "")
        cleaned = str(r[text_i] or "")
        source = source_by_file.get(source_file)
        if not source:
            locator_missing.append(f"未登记来源文件:{source_file}")
            continue
        sid = source["source_id"]
        match = re.search(r"(?:评论序号|数据行|段落)(\d+)", item)
        key = match.group(1) if match else None
        raw_text = locator_maps.get(sid, {}).get(key, "") if key else ""
        if not raw_text:
            locator_missing.append(f"{r[id_i]}->{source_file}/{item}")
            continue
        if cleaned and cleaned in raw_text:
            exact_matches += 1
        exact_checks += 1

    expected_ranges = index_item.get("evidence_id_ranges", {})
    range_errors = []
    for sid, (start, end) in expected_ranges.items():
        source = next((x for x in manifest.get("sources", []) if x["source_id"] == sid), None)
        if not source:
            range_errors.append(f"manifest缺少source_id:{sid}")
            continue
        subset = [str(r[id_i]).zfill(4) for r in data if str(r[src_i]) == source["file_name"]]
        if subset and (min(subset) != start or max(subset) != end):
            range_errors.append(f"{sid}编号范围实际{min(subset)}-{max(subset)}，期望{start}-{end}")

    ok = (
        len(data) == v["data_rows"] and duplicate_count == 0 and contiguous
        and not mismatches and not locator_missing and not range_errors
    )
    detail = (
        f"总记录{len(data)}，重复编号{duplicate_count}，编号连续={'是' if contiguous else '否'}；"
        f"原始定位存在={len(data)-len(locator_missing)}/{len(data)}；"
        f"清洗文本精确包含匹配={exact_matches}/{exact_checks}；"
        f"来源计数差异={mismatches or '无'}；编号范围差异={range_errors or '无'}"
    )
    if locator_missing:
        detail += f"；定位缺失示例={locator_missing[:5]}"
    return ok, detail

def main():
    ap = argparse.ArgumentParser(description="核验访谈项目原始来源、原始条目定位和清洗证据索引")
    ap.add_argument("--manifest", default="assets/source_manifest.json")
    ap.add_argument("--root", default=".", help="原始文件所在目录")
    ap.add_argument("--skip-hash", action="store_true", help="仅检查结构和定位，不建议用于正式访谈")
    args = ap.parse_args()

    with open(args.manifest, "r", encoding="utf-8") as f:
        manifest = json.load(f)
    load_workbook = load_openpyxl()
    errors = 0
    print("来源文件核验")
    for item in manifest.get("sources", []):
        path = os.path.join(args.root, item["file_name"])
        if not os.path.isfile(path):
            print(f"[FAIL] {item['source_id']}: 文件不存在：{path}")
            errors += 1
            continue
        size = os.path.getsize(path)
        size_ok = size == item.get("size_bytes")
        hash_ok = True if args.skip_hash else sha256(path) == item.get("sha256")
        try:
            actual, structure_msg = check_source_structure(path, item, load_workbook)
        except Exception as e:
            actual, structure_msg = None, f"结构读取失败：{e}"
        structure_ok = actual is None or actual == item.get("observed_record_count")
        ok = size_ok and hash_ok and structure_ok
        print(f"[{'OK' if ok else 'FAIL'}] {item['source_id']} | size={size} ({'匹配' if size_ok else '不匹配'}) | sha256={'跳过' if args.skip_hash else ('匹配' if hash_ok else '不匹配')} | {structure_msg}")
        if not ok:
            errors += 1

    for item in manifest.get("derived_indexes", []):
        path = os.path.join(args.root, item["file_name"])
        if not os.path.isfile(path):
            print(f"[FAIL] {item['source_id']}: 清洗索引不存在：{path}")
            errors += 1
            continue
        size_ok = os.path.getsize(path) == item.get("size_bytes")
        hash_ok = True if args.skip_hash else sha256(path) == item.get("sha256")
        try:
            index_ok, detail = check_index(path, item, manifest, args.root, load_workbook)
        except Exception as e:
            index_ok, detail = False, f"索引检查失败：{e}"
        ok = size_ok and hash_ok and index_ok
        print(f"[{'OK' if ok else 'FAIL'}] {item['source_id']} | size={'匹配' if size_ok else '不匹配'} | sha256={'跳过' if args.skip_hash else ('匹配' if hash_ok else '不匹配')} | {detail}")
        if not ok:
            errors += 1

    print(f"\n结果：{'全部通过' if errors == 0 else str(errors) + '项未通过'}")
    if errors:
        print("注意：文件缺失、哈希变化、原始定位缺失或编号范围不符时，应暂停来源模拟并重新核对manifest。")
    return 1 if errors else 0

if __name__ == "__main__":
    sys.exit(main())
